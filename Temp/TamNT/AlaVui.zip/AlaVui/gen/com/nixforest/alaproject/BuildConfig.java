/** Automatically generated file. DO NOT MODIFY */
package com.nixforest.alaproject;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}